import os
import sys
import json
from collections import OrderedDict


# 应用配置加载工具类
class ConfParser:
    # 所有配置参数的对象实例
    __instance = None
    config = None
    std_tags = {}

    def __new__(cls, *args, **kwargs):
        if not cls.__instance:
            cls.__instance = object.__new__(cls)
        return cls.__instance

    def __init__(self, conf_file=""):
        # 将项目绝对路径添加到系统配置中
        if not conf_file:
            conf_file = os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + "/conf/config.json"
            sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
        # 配置信息加载
        if not self.config:
            # 配置为空时读取配置文件
            with open(conf_file) as json_file:
                print("ConfParser加载配置")
                conf_dict = json.load(json_file)
                # 配置信息保存进对象中
                self.config = conf_dict
        # 加载基因组位点配置文件
        if self.config and self.config.get("std_site_files"):
            # 遍历标准位点配置文件列表
            for file_name in self.config.get("std_site_files"):
                file_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + "/conf/" + file_name
                print("tag文件路径：",file_path)
                isfile_flag = os.path.isfile(file_path)
                print(file_name,"文件存在判定结果：",isfile_flag)
                if isfile_flag:
                    # 加载每一个位点配置文件
                    with open(file_path,'r') as tag_file:
                        tmp_dict = OrderedDict()
                        for line in tag_file:
                            line = line.strip()
                            site, pos, tag = line.split("\t")
                            tagR = ''
                            for base in reversed(tag):
                                tagR += base
                            table = tagR.maketrans("[]ATGC", "][TACG")
                            tagRC = tagR.translate(table)
                            tmp_dict[site] = [pos, tag, tagRC]
                        # 将解析后的标准位点信息，按照微生物名（微生物标准点位文件名）保存起来
                        self.std_tags[os.path.splitext(file_name)[0]] = tmp_dict
                print(file_name, "文件加载完成！")


if __name__ == '__main__':
    parser = ConfParser()
    print(parser.config)
    print(parser.std_tags)
